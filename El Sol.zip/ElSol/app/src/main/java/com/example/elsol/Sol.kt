package com.example.elsol

class Sol(var nombre: String, var logo: Int) {


}