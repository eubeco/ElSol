package com.example.elsol

class Planeta(var nombre: String, var diametro: Double, var distancia: Double, var densidad: Int)